﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BankingSite.Models
{
    public class BankingSiteDbInitializer : System.Data.Entity.DropCreateDatabaseAlways<BankingSitedDb>
    {

    }
}