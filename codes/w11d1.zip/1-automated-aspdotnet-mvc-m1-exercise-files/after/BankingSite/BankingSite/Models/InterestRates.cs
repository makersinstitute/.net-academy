﻿namespace BankingSite.Models
{
    public class InterestRates
    {
        public decimal LoanRate { get; set; }
        public decimal CreditCardRate { get; set; }
        public decimal TermDepositRate { get; set; }
    }
}